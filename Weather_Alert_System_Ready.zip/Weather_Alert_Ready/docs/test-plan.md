# Test plan and manual cases
Scope: rule engine, database integration, admin UI and simulated delay monitoring. Entry: dependencies installed and server running. Exit: all automated and manual checks pass; investigate failures. Risks: false alerts, missed alerts, late alerts, invalid data. No live delivery or load test is claimed.

| ID | Rain mm | Wind km/h | Delay s | Expected |
|---|---:|---:|---:|---|
| M01 | 20 | 30 | 10 | SAFE, no record |
| M02 | 100 | 30 | 30 | FLOOD, ON TIME |
| M03 | 20 | 75 | 30 | STORM, ON TIME |
| M04 | 100 | 75 | 30 | Both hazards |
| M05 | 100 | 30 | 599 | ON TIME |
| M06 | 100 | 30 | 600 | LATE |
| M07 | 100 | 30 | 601 | LATE |
| M08 | -1 | 30 | 10 | Validation rejects |
| M09 | 99 | 74 | 10 | SAFE |
| M10 | 100 | 30 | 30 | Refresh dashboard; persisted record |

Use district Mysuru, enter values, click Evaluate weather, compare result, refresh dashboard and record actual result/pass/fail. All manual results pending.

Traceability: flood/storm detection → test_rules; delay limit → test_delay/test_late_monitor; persistence → test_integration_flood/test_integration_storm; invalid inputs → test_bad_request; target/channel metadata → test_target. Actual 200,000-person throughput remains unverified.

Kanban suggested board: To Do (live provider integration, load testing), In Progress (local validation), Review (test evidence), Done (prototype code authored). V-Model mapping: requirements ↔ acceptance checks; system design ↔ system tests; component design ↔ integration tests; implementation ↔ unit tests.

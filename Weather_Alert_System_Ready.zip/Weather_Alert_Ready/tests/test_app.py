import pytest
from app import create_app, evaluate, delivery_status

@pytest.fixture
def client(tmp_path):
    return create_app(str(tmp_path/'test.db')).test_client()

@pytest.mark.parametrize('rain,wind,expected',[(0,0,[]),(99.9,74.9,[]),(100,0,['FLOOD']),(101,0,['FLOOD']),(0,75,['STORM']),(0,76,['STORM']),(100,75,['FLOOD','STORM'])])
def test_rules(rain,wind,expected): assert evaluate(rain,wind)==expected

@pytest.mark.parametrize('rain,wind',[(-1,0),(0,-1),(float('nan'),0),(0,float('inf'))])
def test_invalid_rules(rain,wind):
    with pytest.raises(ValueError): evaluate(rain,wind)

@pytest.mark.parametrize('delay,expected',[(0,'ON TIME'),(599.9,'ON TIME'),(600,'LATE'),(601,'LATE')])
def test_delay(delay,expected): assert delivery_status(delay)==expected

def send(client,**kw):
    return client.post('/api/alerts',json=dict(district='Mysuru',rain=100,wind=0,delay=30)|kw)

def test_integration_flood(client):
    assert send(client).json['hazards']==['FLOOD']; assert b'FLOOD' in client.get('/').data

def test_integration_storm(client):
    assert send(client,rain=0,wind=75).json['hazards']==['STORM']; assert client.get('/api/monitor').json['total']==1

def test_safe(client):
    assert send(client,rain=0).json['status']=='SAFE'; assert client.get('/api/monitor').json['total']==0

def test_both(client):
    assert len(send(client,wind=75).json['hazards'])==2; assert client.get('/api/monitor').json['total']==2

def test_late_monitor(client):
    send(client,delay=600); assert client.get('/api/monitor').json['late']==1

@pytest.mark.parametrize('change',[{'district':''},{'rain':'bad'},{'wind':-1},{'delay':-1},{'delay':'nan'}])
def test_bad_request(client,change): assert send(client,**change).status_code==400

def test_health(client): assert client.get('/api/health').json['status']=='ok'
def test_target(client):
    d=send(client).json; assert d['target_residents']==200000 and d['simulated'] and d['channels']==['SMS','APP']
